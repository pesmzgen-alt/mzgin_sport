Mzgin.Sport — ڕێنماییا بڵاوکرنێ ژ ئایفۆن

چی د ناڤ ZIP ـێ دا هەیە؟
- index.html: ڕووکەرێ وێبسایتێ
- style.css: دیزاین و ڕەنگ
- script.js: ئەنجام و یاریێن ئەمڕۆ/سبەی
- netlify/functions/matches.mjs: API ـێ پاراستی ل سێرڤەر
- netlify.toml: ڕێکخستنێن Netlify

گرنگ:
1) ئەڤ ZIP ـە هێشتا بڵاو نەکریەوە. داتای لایڤ پاش بڵاوکرنێ و دانانا API token کار دکەت.
2) داتای فوتبۆل ژ football-data.org دهێت. پلانا بەلاش دەتوانیت لیگێن سنووردار بگرێتەڤە.
3) هەرگیز FOOTBALL_DATA_TOKEN ل index.html یان script.js مەدانە؛ تەنێ ل Netlify Environment variables دایبنێ.
4) کارتەکێن هەواڵێن ل بەشێ "هەواڵێن فوتبۆلێ" دا نموونەن، هێشتا بە API ـێ هەواڵان نەهاتیە گرێدان.

بڵاوکرنا وێبسایتێ:
A) ZIP ـەکە ل iPhone دابگرە و ل Files بکەرەوە.
B) پێویستە فایلەکان بۆ GitHub repository بار بکەیت، پاشان ل Netlify ئەو repository ـە پەیوەست بکەیت. بۆ Netlify Functions، بارکرنا HTML تەنێ بەس نییە.
C) ل Netlify: Site configuration / Environment variables (یان Environment variables) ـێ بکەرەوە.
D) variable ـەکە زیاد بکە:
   Key: FOOTBALL_DATA_TOKEN
   Value: API token ـێ football-data.org
E) پاش دانان، Deploy ـێ نوو بکە. پاشان لینکێ وێبسایتێ بکەرەوە و ئەنجامان تاقی بکە.

ئەگەر هەر هەنگاوەکێ ل مۆبایلێ جیاواز بوو، وێنەی شاشەکە بنێرە و دێ هەنگاو ب هەنگاو ڕێنماییت کەم.
